import 'package:flutter/material.dart';

class ModelminLogin {
  int grupjk;
  TextEditingController edc_username = new TextEditingController();
  TextEditingController edc_password = new TextEditingController();

  FocusNode foc_username = new FocusNode();
  FocusNode foc_password= new FocusNode();
}

class ModelminHome {
  ScrollController scrollController = new ScrollController();
  bool lastStatus = true;
  double fullWidth = 0;
  double fullHeight = 0;
  String nama="";

  List dataAdmin;
}

class ModelminKelolaGejala{
  ScrollController scrollController = new ScrollController();
  List dataGejala;
  int reloadData = 0;
}

class ModelminTambahGejala{
  TextEditingController edc_gejala = new TextEditingController();

  FocusNode foc_gejala = new FocusNode();
}


class ModelminDetailGejala{
  List dataGejala;
  List dataHimpunan;
  String nama_gejala ="";
  String kode_gejala ="";
}

class ModelminPembentukanRule{
  List dataRule;
  bool isSearch = false;
  TextEditingController edc_search = new TextEditingController();
  FocusNode foc_search = new FocusNode();
  String wordSearch = "";

}

class ModelminDetailRule{
  List dataRule;
  List dataGejala;
  int totalGejala = 0;
  List<String> rule;
}

class ModelminPelatihan{
  List data;
  bool isEmpty = true;
  bool isSearch = false;
  int jumlahData = 0;
  TextEditingController edc_search = new TextEditingController();
  FocusNode foc_search = new FocusNode();
  String wordSearch = "";
  int reloadData = 0;
  bool loading = false;
}

class ModelminPengujian{
  List data;
  bool isEmpty = true;
  bool isSearch = false;
  int jumlahData = 0;
  TextEditingController edc_search = new TextEditingController();
  FocusNode foc_search = new FocusNode();
  String wordSearch = "";
  int reloadData = 0;
  bool loading = false;
}

class ModelminHasilPelatihan{
  List data;
  int epoch = 0;
  double jumlahData  = 0;
  String bestBobot  = "";
  double bestBias   = 0;
  bool showProses = false;
  String title = "Hasil Pelatihan";
}

class ModelminHasilPengujian{
  List data;
  int epoch = 0;
  double jumlahData  = 0;
  double jumlahakurat = 0;
  double presentasiAkurat = 0;
  bool showProses = false;
  String title = "Hasil Pengujian";
}
