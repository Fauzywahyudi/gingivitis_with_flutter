import 'package:flutter/material.dart';

class ModelSplashscreen {
  bool isNew = false;
}

class ModelKonsultasi {
  String ketGejala;
  String gejala;
  int mulaiGejala = 0;
  int maksGejala;
  double fullWidth;
  double fullHeight;

  bool select_tidak = false;
  bool select_mungkin = false;
  bool select_iya =false;
  int jawaban = 0;
  List dataGejala = null;

  String nama = "";
  String jk = "";
  int umur = 0;
  String nohp = "";
  List pola_jawaban;

}

class ModelHome {
  ScrollController scrollController = new ScrollController();
  bool lastStatus = true;
  double fullWidth = 0;
  double fullHeight = 0;
  String nama="";

}

class ModelDataDiri {
  int grupjk;
  TextEditingController edc_nama = new TextEditingController();
  TextEditingController edc_umur = new TextEditingController();
  TextEditingController edc_nohp = new TextEditingController();

  FocusNode foc_nama = new FocusNode();
  FocusNode foc_umur = new FocusNode();
  FocusNode foc_nohp = new FocusNode();

}