import 'package:flutter/material.dart';

class LinkSource {

  static final String getGejala = "http://10.0.2.2/skripsi_gingivitis/getGejala.php";

  static final String prosesKonsultasi = "http://10.0.2.2/skripsi_gingivitis/prosesKonsultasi.php";


  static final String loginAdmin = "http://10.0.2.2/skripsi_gingivitis/admin/loginAdmin.php";
  static final String getDataAdmin = "http://10.0.2.2/skripsi_gingivitis/admin/getDataAdmin.php";
  static final String getDetailGejala = "http://10.0.2.2/skripsi_gingivitis/admin/getDetailGejala.php";
  static final String getRuleFuzzy = "http://10.0.2.2/skripsi_gingivitis/admin/getRuleFuzzy.php";
  static final String buildRuleFuzzy = "http://10.0.2.2/skripsi_gingivitis/admin/buildRuleFuzzy.php";
  static final String searchRule = "http://10.0.2.2/skripsi_gingivitis/admin/searchRule.php";
  static final String getDetailRule = "http://10.0.2.2/skripsi_gingivitis/admin/getDetailRule.php";
  static final String getHimpunanGejala = "http://10.0.2.2/skripsi_gingivitis/admin/getHimpunanGejala.php";
  static final String getDataPelatihan = "http://10.0.2.2/skripsi_gingivitis/admin/getDataPelatihan.php";
  static final String searchDataRulePelatihan = "http://10.0.2.2/skripsi_gingivitis/admin/searchDataRulePelatihan.php";
  static final String prosesPelatihan = "http://10.0.2.2/skripsi_gingivitis/admin/prosesPelatihan.php";
  static final String resetDataPelatihan = "http://10.0.2.2/skripsi_gingivitis/admin/resetDataPelatihan.php";
  static final String resetProsesPelatihan = "http://10.0.2.2/skripsi_gingivitis/admin/resetProsesPelatihan.php";
  static final String hasilPelatihan = "http://10.0.2.2/skripsi_gingivitis/admin/hasilPelatihan.php";
  static final String showProsesPelatihan = "http://10.0.2.2/skripsi_gingivitis/admin/showProsesPelatihan.php";



  static final String addDataPelatihan = "http://10.0.2.2/skripsi_gingivitis/admin/addDataPelatihan.php";
  static final String tambahGejala = "http://10.0.2.2/skripsi_gingivitis/admin/tambahGejala.php";
  static final String hapusGejala = "http://10.0.2.2/skripsi_gingivitis/admin/hapusGejala.php";




  static final String getDataPengujian = "http://10.0.2.2/skripsi_gingivitis/admin/getDataPengujian.php";
  static final String searchDataRulePengujian = "http://10.0.2.2/skripsi_gingivitis/admin/searchDataRulePengujian.php";
  static final String prosesPengujian = "http://10.0.2.2/skripsi_gingivitis/admin/prosesPengujian.php";
  static final String resetDataPengujian = "http://10.0.2.2/skripsi_gingivitis/admin/resetDataPengujian.php";
  static final String addDataPengujian = "http://10.0.2.2/skripsi_gingivitis/admin/addDataPengujian.php";
  static final String showProsesPengujian = "http://10.0.2.2/skripsi_gingivitis/admin/showProsesPengujian.php";
  static final String hasilPengujian = "http://10.0.2.2/skripsi_gingivitis/admin/hasilPengujian.php";
}