import 'package:flutter/material.dart';
import 'package:gingivitis/sqlite/DBHelper.dart';
import 'package:gingivitis/model/model.dart';
import 'dart:async';
import 'package:gingivitis/activity/user/home.dart';
import 'package:gingivitis/activity/user/data_diri.dart';

class Splashscreen extends StatefulWidget {
  @override
  _SplashscreenState createState() => _SplashscreenState();
}

class _SplashscreenState extends State<Splashscreen> {

  ModelSplashscreen model = new ModelSplashscreen();

  Future<int> cek_user() async {
    var db = DBHelper();
    int cek = await db.cekUser();
    setState(() {
      if (cek > 0) {
        model.isNew = false;
      } else {
        model.isNew = true;
      }
    });
    print(cek.toString());
    return cek;
  }

  @override
  void initState() {
    cek_user();
    Timer(
        Duration(seconds: 4),
            () => Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => model.isNew == true
                ? new DataDiri()
                : new HomePage())));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(),
    );
  }
}
