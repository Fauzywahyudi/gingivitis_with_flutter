import 'package:flutter/material.dart';

class LaporanKonsultasi extends StatefulWidget {
  @override
  _LaporanKonsultasiState createState() => _LaporanKonsultasiState();
}

class _LaporanKonsultasiState extends State<LaporanKonsultasi> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Laporan Konsultasi"),
        
      ),
      body: Container(),
    );
  }
}
