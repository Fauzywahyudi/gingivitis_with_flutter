import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:gingivitis/model/modeladmin.dart';
import 'package:gingivitis/sqlite/DBHelper.dart';
import 'package:gingivitis/mysql/link.dart' as link;
import 'package:http/http.dart' as http;
import 'package:gingivitis/activity/admin/pembentukan_rule.dart';

class HomeAdmin extends StatefulWidget {
  HomeAdmin({this.id});

  final String id;

  @override
  _HomeAdminState createState() => _HomeAdminState();
}

class _HomeAdminState extends State<HomeAdmin> {
  ModelminHome model = new ModelminHome();

  Future<int> getDataAdmin() async {
    final result = await http.post(link.LinkSource.getDataAdmin, body: {
      "id": widget.id,
    });

    model.dataAdmin = json.decode(result.body);
    setState(() {
      model.nama = model.dataAdmin[0]['nama_lengkap'];
    });
    print(model.dataAdmin);
  }

  Future<int> konfirmLogout()async{

    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(
                "Konfirmasi"),
            content: Text("Apakah anda yakin untuk Logout ?"),
            actions: <Widget>[
              FlatButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.pushReplacementNamed(
                        context, '/splashscreen');
                  },
                  child: Text(
                    "Iya",
                    style:
                    TextStyle(color: Colors.green),
                  )),
              FlatButton(
                  onPressed: () =>
                      Navigator.pop(context),
                  child: Text("Tidak",
                      style: TextStyle(
                          color: Colors.red))),
            ],
          );
        });

  }

  @override
  void initState() {
    getDataAdmin();
//    model.scrollController.addListener(_scrollListener);
//    getDataAdmin();
    super.initState();
  }

  @override
  void dispose() {
    model.scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    model.fullWidth = MediaQuery.of(context).size.width;
    model.fullHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      body: NestedScrollView(
          controller: model.scrollController,
          headerSliverBuilder:
              (BuildContext context, bool innerViewIsScrolled) {
            return <Widget>[
              SliverAppBar(
                actions: <Widget>[
                  IconButton(
                      icon: Icon(
                        Icons.person,
                        color: Colors.white,
                      ),
                      onPressed: () => konfirmLogout())
                ],
                backgroundColor: Colors.blue,
                pinned: false,
                floating: true,
                snap: false,
                expandedHeight: model.fullHeight / 5 + 20,
                flexibleSpace: FlexibleSpaceBar(
                  background: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      Container(
                        width: model.fullWidth / 4,
                        height: model.fullWidth / 4,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle, color: Colors.white),
                        child: Icon(
                          Icons.account_box,
                          size: model.fullWidth / 4.5,
                          color: Colors.blue,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Text(
                          model.nama.toUpperCase(),
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.white),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ];
          },
          body: menu()),
    );
  }

  Widget menu() {
    return ListView(
      padding: EdgeInsets.only(top: 0),
      children: <Widget>[
        Container(
          padding: EdgeInsets.only(top: 10),
          child: Container(
            child: Row(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.blue,
                  ),
                  width: model.fullWidth / 2 - 40,
                  height: model.fullHeight / 5,
                  margin:
                      EdgeInsets.only(left: 20, right: 20, top: 10, bottom: 10),
                  child: InkWell(
                    onTap: () =>
                        Navigator.pushNamed(context, '/laporankonsultasi'),
                    child: Center(
                      child: Text(
                        "Laporan Konsultasi",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.blue),
                  width: model.fullWidth / 2 - 40,
                  height: model.fullHeight / 5,
                  margin:
                      EdgeInsets.only(left: 20, right: 20, top: 10, bottom: 10),
                  child: InkWell(
                    onTap: () => Navigator.pushNamed(context, '/kelolagejala'),
                    child: Center(
                      child: Text(
                        "Kelola Gejala",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Container(
          child: Row(
            children: <Widget>[
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.blue),
                width: model.fullWidth / 2 - 40,
                height: model.fullHeight / 5,
                margin:
                    EdgeInsets.only(left: 20, right: 20, top: 10, bottom: 10),
                child: InkWell(
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) => PembentukanRule(
                                title: "Pembentukkan Rule",
                              ))),
                  child: Center(
                    child: Text(
                      "Pembentukan Rule Fuzzy",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.blue),
                width: model.fullWidth / 2 - 40,
                height: model.fullHeight / 5,
                margin:
                    EdgeInsets.only(left: 20, right: 20, top: 10, bottom: 10),
                child: InkWell(
                  onTap: () => Navigator.pushNamed(context, '/pelatihan'),
                  child: Center(
                    child: Text(
                      "Pelatihan Perceptron",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          child: Row(
            children: <Widget>[
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.blue),
                width: model.fullWidth / 2 - 40,
                height: model.fullHeight / 5,
                margin:
                    EdgeInsets.only(left: 20, right: 20, top: 10, bottom: 10),
                child: InkWell(
                  onTap: () => Navigator.pushNamed(context, '/pengujian'),
                  child: Center(
                    child: Text(
                      "Pengujian Perceptron",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.blue),
                width: model.fullWidth / 2 - 40,
                height: model.fullHeight / 5,
                margin:
                    EdgeInsets.only(left: 20, right: 20, top: 10, bottom: 10),
                child: InkWell(
                  onTap: () => Navigator.pushNamed(context, '/solusi'),
                  child: Center(
                    child: Text(
                      "Kelola Informasi",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

//  _scrollListener() {
//    if (isShrink != model.lastStatus) {
//      setState(() {
//        model.lastStatus = isShrink;
//      });
//    }
//  }
//
//  bool get isShrink {
//    return model.scrollController.hasClients &&
//        model.scrollController.offset > (model.fullHeight/5 +15 - kToolbarHeight);
//  }
}
