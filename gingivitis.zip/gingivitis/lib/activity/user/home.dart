import 'package:flutter/material.dart';
import 'package:gingivitis/model/model.dart';
import 'package:gingivitis/sqlite/DBHelper.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  ModelHome model = new ModelHome();

  Future<List> getDataUser()async{
    var db = new DBHelper();
    List<Map> list = await db.getData();
    setState(() {
      model.nama = list[0]['nama'];
    });
    print(model.nama);
  }

  @override
  void initState() {
    getDataUser();

//    model.scrollController.addListener(_scrollListener);
    getDataUser();
    super.initState();
  }
  @override
  void dispose() {
    model.scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    model.fullWidth = MediaQuery.of(context).size.width;
    model.fullHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      body: NestedScrollView(
        controller: model.scrollController,
        headerSliverBuilder: (BuildContext context, bool innerViewIsScrolled) {
          return <Widget>[
            SliverAppBar(

              actions: <Widget>[
                    IconButton(
                      icon: Icon(Icons.lock),color: Colors.white,
                      onPressed: ()=>Navigator.pushReplacementNamed(context, '/loginadmin'),
                    )
              ],
              backgroundColor: Colors.blue,
              pinned: false,
              floating: true,
              snap: false,
              expandedHeight: model.fullHeight / 5 + 20,
              flexibleSpace: FlexibleSpaceBar(
                background: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Container(
                      width: model.fullWidth / 4,
                      height: model.fullWidth / 4,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle, color: Colors.white),
                      child: Icon(
                        Icons.person,
                        size: model.fullWidth / 4,
                        color: Colors.blue,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Text(
                        model.nama.toUpperCase(),
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ];
        },
        body: menu()
      ),
    );
  }


  Widget menu(){
    return
      ListView(
        padding: EdgeInsets.only(top: 0),
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(top: 10),
            child: Container(
              child: Row(
                children: <Widget>[
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.blue,
                    ),
                    width: model.fullWidth / 2 - 40,
                    height: model.fullHeight / 5,
                    margin: EdgeInsets.only(left: 20,right: 20,top: 10,bottom: 10),
                    child: InkWell(
                      onTap: () => Navigator.pushReplacementNamed(context, '/konsultasi'),
                      child: Center(
                        child: Text(
                          "Konsultasi",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.blue),
                    width: model.fullWidth / 2 - 40,
                    height: model.fullHeight / 5,
                    margin: EdgeInsets.only(left: 20,right: 20,top: 10,bottom: 10),
                    child: InkWell(
                      onTap: () => Navigator.pushNamed(context, '/infopenyakit'),
                      child: Center(
                        child: Text(
                          "Info Penyakit",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            child: Row(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.blue),
                  width: model.fullWidth / 2 - 40,
                  height: model.fullHeight / 5,
                  margin: EdgeInsets.only(left: 20,right: 20,top: 10,bottom: 10),
                  child: InkWell(
                    onTap: () => Navigator.pushNamed(context, '/infogejala'),
                    child: Center(
                      child: Text(
                        "Info Gejala",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.blue),
                  width: model.fullWidth / 2 - 40,
                  height: model.fullHeight / 5,
                  margin: EdgeInsets.only(left: 20,right: 20,top: 10,bottom: 10),
                  child: InkWell(
                    onTap: () => Navigator.pushNamed(context, '/pencegahan'),
                    child: Center(
                      child: Text(
                        "Pencegahan",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            child: Row(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.blue),
                  width: model.fullWidth / 2 - 40,
                  height: model.fullHeight / 5,
                  margin: EdgeInsets.only(left: 20,right: 20,top: 10,bottom: 10),
                  child: InkWell(
                    onTap: () => Navigator.pushNamed(context, '/solusi'),
                    child: Center(
                      child: Text(
                        "Solusi",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ),
//                  Container(
//                    decoration: BoxDecoration(
//                        borderRadius: BorderRadius.circular(20),
//                        color: Colors.red),
//                    width: model.fullWidth / 2 - 40,
//                    height: model.fullHeight / 5,
//                    margin: EdgeInsets.only(left: 20,right: 20,top: 10,bottom: 10),
//                    child: InkWell(
//                      onTap: () {},
//                      child: Center(
//                        child: Text(
//                          "Keluar",
//                          style: TextStyle(
//                              fontSize: 20,
//                              fontWeight: FontWeight.bold,
//                              color: Colors.white),
//                        ),
//                      ),
//                    ),
//                  ),
              ],
            ),
          ),
        ],
      );
  }

}
