import 'package:flutter/material.dart';
import 'package:gingivitis/model/model.dart';


class Solusi extends StatefulWidget {
  @override
  _SolusiState createState() => _SolusiState();
}

class _SolusiState extends State<Solusi> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Solusi"),
      ),
      body: Container(),
    );
  }
}
