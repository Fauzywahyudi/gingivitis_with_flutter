import 'package:flutter/material.dart';
import 'package:gingivitis/model/model.dart';

class InfoGejala extends StatefulWidget {
  @override
  _InfoGejalaState createState() => _InfoGejalaState();
}

class _InfoGejalaState extends State<InfoGejala> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Info Gejala"),
      ),
      body: Container(),
    );
  }
}
