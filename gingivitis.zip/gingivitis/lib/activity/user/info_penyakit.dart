import 'package:flutter/material.dart';
import 'package:gingivitis/model/model.dart';

class InfoPenyakit extends StatefulWidget {
  @override
  _InfoPenyakitState createState() => _InfoPenyakitState();
}

class _InfoPenyakitState extends State<InfoPenyakit> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Info Penyakit"),
      ),
      body: Container(),
    );
  }
}
