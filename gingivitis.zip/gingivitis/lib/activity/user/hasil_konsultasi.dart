import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:gingivitis/model/model.dart';
import 'package:gingivitis/mysql/link.dart' as link;
import 'package:http/http.dart' as http;
import 'package:gingivitis/sqlite/DBHelper.dart';

class HasilKonsultasi extends StatefulWidget {
  @override
  _HasilKonsultasiState createState() => _HasilKonsultasiState();
}

class _HasilKonsultasiState extends State<HasilKonsultasi> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Hasil Konsultasi"),
        actions: <Widget>[
          IconButton(icon: Icon(Icons.exit_to_app),
          onPressed: (){
            Navigator.pushReplacementNamed(context, '/home');
          })
        ],
      ),
      body: Container(
        child: Center(
          child: CircularProgressIndicator(),
        ),
      ),
    );
  }
}
