import 'package:flutter/material.dart';
import 'package:gingivitis/model/model.dart';

class Pencegahan extends StatefulWidget {
  @override
  _PencegahanState createState() => _PencegahanState();
}

class _PencegahanState extends State<Pencegahan> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pencegahan"),
      ),
      body: Container(),
    );
  }
}
