import 'package:flutter/material.dart';
import 'package:gingivitis/sqlite/DBHelper.dart';
import 'package:gingivitis/model/model.dart';
import 'package:fluttertoast/fluttertoast.dart';

class DataDiri extends StatefulWidget {
  @override
  _DataDiriState createState() => _DataDiriState();
}

class _DataDiriState extends State<DataDiri> {
  ModelDataDiri model = ModelDataDiri();

  Future<int> addDataDiri(String nama, int jk, int umur, String nohp) async {
    var db = DBHelper();
    String jekel;
    if (jk == 1) {
      jekel = "laki-laki";
    } else if (jk == 2) {
      jekel = "perempuan";
    }
    int res = await db.addData(nama, jekel, umur, nohp);
    if (res == 1) {
      Navigator.pushReplacementNamed(context, '/home');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.blue,
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Stack(
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.only(top: 50),
                    height: 200,
                    color: Colors.blue,
                    child: Center(
                      child: Text(
                        "Input Data Diri untuk Melanjutkan Aplikasi ini",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontSize: 30),
                      ),
                    ),
                  ),
                  SafeArea(
                    child: Container(
                      height: 60,
                      color: Colors.blue,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          IconButton(
                              icon: Icon(
                                Icons.lock,
                                color: Colors.white,
                              ),
                              onPressed: () => Navigator.pushReplacementNamed(
                                  context, '/loginadmin'))
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              Container(
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    Container(
                      margin: const EdgeInsets.all(8.0),
                      child: TextField(
                        controller: model.edc_nama,
                        focusNode: model.foc_nama,
                        textInputAction: TextInputAction.next,
                        textCapitalization: TextCapitalization.words,
                        onSubmitted: (v) {
                          FocusScope.of(context).requestFocus(model.foc_umur);
                        },
                        decoration: InputDecoration(labelText: "Nama Lengkap"),
                      ),
                    ),
                    Container(
                        margin: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Jenis Kelamin",
                                style:
                                    TextStyle(fontSize: 18, color: Colors.blue),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      Text(
                                        "Laki-laki",
                                        style: TextStyle(
                                            fontSize: 18, color: Colors.blue),
                                      ),
                                      Radio(
                                        value: 1,
                                        groupValue: model.grupjk,
                                        onChanged: (v) {
                                          rd_jk(v);
                                        },
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: <Widget>[
                                      Text(
                                        "Perempuan",
                                        style: TextStyle(
                                            fontSize: 18, color: Colors.blue),
                                      ),
                                      Radio(
                                        value: 2,
                                        groupValue: model.grupjk,
                                        onChanged: (v) {
                                          rd_jk(v);
                                        },
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        )),
                    Container(
                      margin: const EdgeInsets.all(8.0),
                      child: TextField(
                        controller: model.edc_umur,
                        focusNode: model.foc_umur,
                        textInputAction: TextInputAction.next,
                        onSubmitted: (v) {
                          FocusScope.of(context).requestFocus(model.foc_nohp);
                        },
                        keyboardType: TextInputType.numberWithOptions(),
                        decoration: InputDecoration(labelText: "Umur"),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.all(8.0),
                      child: TextField(
                        controller: model.edc_nohp,
                        focusNode: model.foc_nohp,
                        textInputAction: TextInputAction.done,
                        onSubmitted: (v) {
                          model.foc_nohp.unfocus();
                        },
                        keyboardType: TextInputType.numberWithOptions(),
                        decoration: InputDecoration(labelText: "No. HP"),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.all(20.0),
                      child: RaisedButton(
                        onPressed: () {
                          String nama = model.edc_nama.text;
                          int jk = model.grupjk;
                          int umur = int.parse(model.edc_umur.text);
                          String nohp = model.edc_nohp.text;
                          addDataDiri(nama, jk, umur, nohp);
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text("Simpan",
                              style:
                                  TextStyle(color: Colors.white, fontSize: 20)),
                        ),
                        color: Colors.blue,
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  void rd_jk(int v) {
    setState(() {
      if (v == 1) {
        model.grupjk = 1;
      } else if (v == 2) {
        model.grupjk = 2;
      }
    });
  }
}
