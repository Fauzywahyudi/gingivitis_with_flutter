import 'package:flutter/material.dart';
import 'activity/user/home.dart';
import 'activity/user/konsultasi.dart';
import 'activity/user/info_gejala.dart';
import 'activity/user/info_penyakit.dart';
import 'activity/user/pencegahan.dart';
import 'activity/user/solusi.dart';
import 'activity/user/data_diri.dart';
import 'splashscreen.dart';


import 'activity/admin/login_admin.dart';
import 'activity/admin/home_admin.dart';
import 'activity/user/hasil_konsultasi.dart';
import 'activity/admin/gejala/kelola_gejala.dart';
import 'activity/admin/laporan_konsultasi.dart';
import 'activity/admin/pembentukan_rule.dart';
import 'activity/admin/pelatihan_perceptron.dart';
import 'activity/admin/hasil_pelatihan.dart';
import 'activity/admin/pengujian_perceptron.dart';
import 'activity/admin/gejala/tambah_gejala.dart';
import 'activity/admin/tes.dart';
import 'activity/admin/hasil_pengujian.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false,
      routes: <String, WidgetBuilder>{
        '/konsultasi': (BuildContext context) => new Konsultasi(),
        '/infopenyakit': (BuildContext context) => new InfoPenyakit(),
        '/infogejala': (BuildContext context) => new InfoGejala(),
        '/pencegahan': (BuildContext context) => new Pencegahan(),
        '/solusi': (BuildContext context) => new Solusi(),
        '/datadiri': (BuildContext context) => new DataDiri(),
        '/home': (BuildContext context) => new HomePage(),
        '/splashscreen': (BuildContext context) => new Splashscreen(),
        '/hasilkonsultasi': (BuildContext context) => new HasilKonsultasi(),

        '/loginadmin': (BuildContext context) => new LoginAdmin(),
        '/homeadmin': (BuildContext context) => new HomeAdmin(),
        '/kelolagejala': (BuildContext context) => new KelolaGejala(),
        '/tambahgejala': (BuildContext context) => new TambahGejala(),

        '/laporankonsultasi': (BuildContext context) => new LaporanKonsultasi(),
        '/pembentukkanrule': (BuildContext context) => new PembentukanRule(),
        '/pelatihan': (BuildContext context) => new PelatihanPerceptron(),
        '/hasilpelatihan': (BuildContext context) => new HasilPelatihan(),
        '/pengujian': (BuildContext context) => new PengujianPerceptron(),
        '/hasilpengujian': (BuildContext context) => new HasilPengujian(),




      },
      home: Splashscreen(),
    );
  }
}
